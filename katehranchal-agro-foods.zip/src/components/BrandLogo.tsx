import React from 'react';

interface BrandLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showWordmark?: boolean;
  wordmarkClassName?: string;
  isLightHeader?: boolean;
  variant?: 'light' | 'dark'; // 'dark' = dark text on light bg (default), 'light' = white/gold on dark bg
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  className = '',
  size = 'md',
  showWordmark = false,
  wordmarkClassName = '',
  isLightHeader = false,
  variant = 'dark',
}) => {
  // Height-based sizing to preserve the vertical pointed-leaf aspect ratio
  const sizeMap = {
    sm: 'h-8 sm:h-9 w-auto',
    md: 'h-10 sm:h-12 w-auto',
    lg: 'h-14 sm:h-16 w-auto',
    xl: 'h-20 sm:h-24 w-auto',
  };

  const isLightMode = variant === 'light' || isLightHeader;

  return (
    <div className={`flex items-center gap-3 sm:gap-3.5 select-none ${className}`}>
      <img
        src="/assets/katehranchal-agro-foods-logo.png"
        alt="Katehranchal Agro Foods logo"
        className={`${sizeMap[size]} object-contain shrink-0 transition-transform duration-200`}
        width={size === 'xl' ? 96 : size === 'lg' ? 64 : size === 'md' ? 48 : 36}
        height={size === 'xl' ? 115 : size === 'lg' ? 77 : size === 'md' ? 58 : 43}
        loading="eager"
      />
      {showWordmark && (
        <div className={`flex flex-col justify-center leading-none ${wordmarkClassName}`}>
          {/* Primary Dominant Brand Name in Fraunces SemiBold */}
          <span
            className={`font-serif font-semibold tracking-[0.05em] uppercase transition-colors ${
              size === 'sm' ? 'text-xs sm:text-sm' : size === 'lg' ? 'text-lg sm:text-2xl' : 'text-sm sm:text-lg'
            } ${isLightMode ? 'text-[#FBF9F4]' : 'text-[#124328]'}`}
          >
            Katehranchal
          </span>
          {/* Subordinate Category Line with refined tracking */}
          <span
            className={`font-sans font-semibold tracking-[0.18em] uppercase mt-1 ${
              size === 'sm' ? 'text-[9px] sm:text-[10px]' : size === 'lg' ? 'text-xs sm:text-sm' : 'text-[10px] sm:text-xs'
            } text-[#E0980B]`}
          >
            Agro Foods
          </span>
        </div>
      )}
    </div>
  );
};
